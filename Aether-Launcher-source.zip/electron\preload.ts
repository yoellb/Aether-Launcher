import { contextBridge, ipcRenderer } from 'electron';

contextBridge.exposeInMainWorld('aether', {
  minimize: () => ipcRenderer.send('window:minimize'),
  close: () => ipcRenderer.send('window:close'),
  openDiscord: () => ipcRenderer.invoke('discord:open'),
  openMicrosoft: (url: string) => ipcRenderer.invoke('microsoft:open', url),
  openExternal: (url: string) => ipcRenderer.invoke('external:open', url),
  startMicrosoftLogin: () => ipcRenderer.invoke('microsoft:start'),
  finishMicrosoftLogin: (deviceCode: string, interval: number) => ipcRenderer.invoke('microsoft:finish', deviceCode, interval),
  loadProfile: () => ipcRenderer.invoke('profile:load') as Promise<{ id: string; name: string; skinUrl?: string } | null>,
  clearProfile: () => ipcRenderer.invoke('profile:clear') as Promise<void>,
  maximize: () => ipcRenderer.send('window:maximize'),
  loadAccounts: () => ipcRenderer.invoke('profile:accounts') as Promise<{ id: string; name: string; skinUrl?: string }[]>,
  activateProfile: (id: string) => ipcRenderer.invoke('profile:activate', id) as Promise<{ id: string; name: string; skinUrl?: string }>,
  loadSettings: () => ipcRenderer.invoke('settings:load') as Promise<Record<string, string | boolean>>,
  saveSettings: (settings: Record<string, string | boolean>) => ipcRenderer.invoke('settings:save', settings) as Promise<void>,
  searchModpacks: (query: string, offset = 0) => ipcRenderer.invoke('modpacks:search', query, offset) as Promise<{ items: { id: string; title: string; description: string; version: string; iconUrl?: string; downloads: number; source: 'Modrinth' }[]; hasMore: boolean }>,
  importMrpack: () => ipcRenderer.invoke('modpacks:import') as Promise<{ name: string; path: string } | null>,
  selectCustomIcon: () => ipcRenderer.invoke('instances:icon') as Promise<string | null>,
  createInstanceFromModpack: (modpackId: string, name: string, customIcon?: string | null, iconUrl?: string, background?: string) => ipcRenderer.invoke('instances:create-from-modpack', modpackId, name, customIcon, iconUrl, background) as Promise<{ id: string; name: string; path: string; version: string; modpackId: string; packUrl?: string; iconPath?: string; iconUrl?: string; background?: string; installed?: boolean; createdAt: string }>,
  createVanillaInstance: (name: string, version: string, iconData?: string | null, background?: string, loader?: string, loaderVersion?: string) => ipcRenderer.invoke('instances:create-vanilla', name, version, iconData, background, loader, loaderVersion),
  getMinecraftVersions: () => ipcRenderer.invoke('minecraft:versions') as Promise<{ id: string; type: string }[]>,
  getLoaderVersions: (loader: string, version: string) => ipcRenderer.invoke('minecraft:loader-versions', loader, version) as Promise<{ version: string }[]>,
  listInstances: () => ipcRenderer.invoke('instances:list') as Promise<{ id: string; name: string; path: string; version: string; modpackId: string; iconPath?: string; iconUrl?: string; createdAt: string }[]>,
  openInstanceFolder: (id: string) => ipcRenderer.invoke('instances:open-folder', id) as Promise<void>,
  deleteInstance: (id: string) => ipcRenderer.invoke('instances:delete', id) as Promise<void>,
  installInstance: (id: string) => ipcRenderer.invoke('instances:install', id) as Promise<{ id: string; name: string; path: string; version: string; modpackId: string; installed?: boolean }>,
  launchInstance: (id: string) => ipcRenderer.invoke('instances:launch', id) as Promise<void>,
  stopInstance: (id: string) => ipcRenderer.invoke('instances:stop', id) as Promise<boolean>,
  isInstanceRunning: (id: string) => ipcRenderer.invoke('instances:running', id) as Promise<{ running: boolean; startedAt: number }>,
  onInstanceStatus: (callback: (id: string, running: boolean, startedAt: number) => void) => {
    const listener = (_event: Electron.IpcRendererEvent, id: string, running: boolean, startedAt: number) => callback(id, running, startedAt);
    ipcRenderer.on('instances:status', listener);
    return () => ipcRenderer.removeListener('instances:status', listener);
  },
  onInstanceProgress: (callback: (id: string, percent: number, message: string) => void) => {
    const listener = (_event: Electron.IpcRendererEvent, id: string, percent: number, message: string) => callback(id, percent, message);
    ipcRenderer.on('instances:progress', listener);
    return () => ipcRenderer.removeListener('instances:progress', listener);
  },
  hasInstanceUpdate: (id: string) => ipcRenderer.invoke('instances:update-check', id) as Promise<boolean>,
  updateInstance: (id: string) => ipcRenderer.invoke('instances:update', id),
  checkLauncherUpdates: () => ipcRenderer.invoke('launcher:check-updates') as Promise<{ currentVersion: string; availableVersion: string } | null>,
  onLauncherUpdateStatus: (callback: (status: string, currentVersion?: string, availableVersion?: string) => void) => {
    const listener = (_event: Electron.IpcRendererEvent, status: string, currentVersion?: string, availableVersion?: string) => callback(status, currentVersion, availableVersion);
    ipcRenderer.on('launcher:update-status', listener);
    return () => ipcRenderer.removeListener('launcher:update-status', listener);
  },
  onLauncherUpdateProgress: (callback: (percent: number) => void) => {
    const listener = (_event: Electron.IpcRendererEvent, percent: number) => callback(percent);
    ipcRenderer.on('launcher:update-progress', listener);
    return () => ipcRenderer.removeListener('launcher:update-progress', listener);
  },
});
