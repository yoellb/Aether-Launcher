import { useEffect, useState } from 'react';
import homeIcon from './assets/home.svg';
import instancesIcon from './assets/instances.svg';
import settingsIcon from './assets/settings.svg';
import appearanceIcon from './assets/appearance.svg';
import minecraftIcon from './assets/minecraft.svg';
import launcherIcon from './assets/launcher.svg';
import userIcon from './assets/user.svg';
import notificationsIcon from './assets/notifications.svg';
import discordIcon from './assets/discord.svg';
import logo from './assets/aether-logo.png';
import microsoftIcon from './assets/microsoft.svg';
import addIcon from './assets/add.svg';
import windowMinIcon from './assets/window-min.svg';
import windowMaxIcon from './assets/window-max.svg';
import windowCloseIcon from './assets/window-close.svg';
import welcomeBackground from './assets/welcome-background.jpg';
import folderIcon from './assets/folder.svg';
import heartIcon from './assets/icon-heart.png';
import swordIcon from './assets/icon-sword.png';
import appleIcon from './assets/icon-apple.png';
import { addInstanceMember, loadAvailableCloudInstances, loadCloudProfile, loadInstanceAudit, loadInstanceMembers, startCloudSession, syncMinecraftIdentity, updateCloudInstance, type CloudInstance } from './lib/supabase';

type Page = 'home' | 'instances' | 'settings';
const navItems = [{ id: 'home' as Page, label: 'Inicio', icon: homeIcon }, { id: 'instances' as Page, label: 'Instancias', icon: instancesIcon }, { id: 'settings' as Page, label: 'Ajustes', icon: settingsIcon }];
type SettingsState = Record<string, string | boolean>;
type Instance = { id: string; name: string; path: string; version: string; modpackId: string; packUrl?: string; iconPath?: string; iconUrl?: string; background?: string; installed?: boolean; createdAt: string };
const skinHeadUrl = (profile: { id: string; name: string; skinUrl?: string }) => profile.skinUrl?.includes('mc-heads.net') ? profile.skinUrl : `https://mc-heads.net/avatar/${encodeURIComponent(profile.name)}/64`;
const defaultSettings: SettingsState = {
  language: 'Español', startWithWindows: false, minimizeToTray: true, launcherUpdates: true,
  javaPath: 'C:\\Program Files\\Java\\jdk-17', defaultRam: '4 GB', javaProcess: 'Automático', instancesPath: 'C:\\AetherStudio\\instances',
  javaVersion: 'Java 17 (Recomendada)', gameDirectory: 'C:\\Users\\Yoel\\AppData\\Roaming\\.minecraft', allowMods: true, autoLibraries: true,
  launcherNotifications: true, availableUpdates: true, eventsNews: false, theme: 'Oscuro', accent: '#4c75ff', showBackgrounds: true, animations: true,
};

function App() {
  const [booting, setBooting] = useState(true);
  const [bootProgress, setBootProgress] = useState(0);
  const [page, setPage] = useState<Page>('home');
  const [createOpen, setCreateOpen] = useState(false);
  const [loginOpen, setLoginOpen] = useState(false);
  const [profile, setProfile] = useState<{ id: string; name: string; skinUrl?: string } | null>(null);
  const [cloudRole, setCloudRole] = useState<'creator' | 'instance_admin' | 'player' | null>(null);
  const [cloudInstances, setCloudInstances] = useState<CloudInstance[]>([]);
  const [adminOpen, setAdminOpen] = useState(false);
  const [launcherUpdate, setLauncherUpdate] = useState<{ status: string; current?: string; available?: string; progress: number }>({ status: 'idle', progress: 0 });
  const [accounts, setAccounts] = useState<{ id: string; name: string; skinUrl?: string }[]>([]);
  const [settings, setSettings] = useState<SettingsState>(defaultSettings);
  const [instances, setInstances] = useState<Instance[]>([]);
  const [selectedInstance, setSelectedInstance] = useState<Instance | null>(null);
  const [sidebarMenuId, setSidebarMenuId] = useState<string | null>(null);
  const refreshInstances = () => { if (window.aether) void window.aether.listInstances().then(setInstances); };
  const acceptProfile = (nextProfile: { id: string; name: string; skinUrl?: string }) => {
    setProfile(nextProfile);
    void syncMinecraftIdentity(nextProfile.id, nextProfile.name)
      .then(() => loadCloudProfile())
      .then((cloudProfile) => setCloudRole(cloudProfile?.role ?? null))
      .catch((error: unknown) => console.warn('No se pudo sincronizar la identidad:', error));
  };
  const openSidebarFolder = (instance: Instance) => { setSidebarMenuId(null); if (window.aether) void window.aether.openInstanceFolder(instance.id); };
  const deleteSidebarInstance = (instance: Instance) => { setSidebarMenuId(null); if (window.aether) void window.aether.deleteInstance(instance.id).then(() => { if (selectedInstance?.id === instance.id) setSelectedInstance(null); refreshInstances(); }); };
  useEffect(() => {
    if (!window.aether) { setBooting(false); return; }
    const removeUpdateStatus = window.aether.onLauncherUpdateStatus((status, current, available) => setLauncherUpdate((previous) => ({ ...previous, status, current, available })));
    const removeUpdateProgress = window.aether.onLauncherUpdateProgress((progress) => setLauncherUpdate((previous) => ({ ...previous, progress })));
    void startCloudSession().catch((error: unknown) => console.warn('La sesión en la nube no está disponible:', error));
    const assets = [logo, homeIcon, instancesIcon, settingsIcon, appearanceIcon, minecraftIcon, launcherIcon, userIcon, notificationsIcon, discordIcon, microsoftIcon, addIcon, windowMinIcon, windowMaxIcon, windowCloseIcon, welcomeBackground, folderIcon, heartIcon, swordIcon, appleIcon];
    const loadAssets = Promise.all(assets.map((src) => new Promise<void>((resolve) => {
      const image = new Image();
      image.onload = () => resolve();
      image.onerror = () => resolve();
      image.src = src;
    })));
    const loadData = Promise.all([window.aether.loadProfile(), window.aether.loadAccounts(), window.aether.loadSettings(), window.aether.listInstances()]);
    setBootProgress(15);
    void Promise.all([loadAssets, loadData]).then(([, [savedProfile, savedAccounts, savedSettings, savedInstances]]) => {
      setBootProgress(85);
      if (savedProfile) {
        void syncMinecraftIdentity(savedProfile.id, savedProfile.name)
          .then(() => loadCloudProfile())
          .then((cloudProfile) => setCloudRole(cloudProfile?.role ?? null))
          .catch((error: unknown) => console.warn('No se pudo sincronizar la identidad:', error));
      }
      void loadAvailableCloudInstances().then(setCloudInstances).catch((error: unknown) => console.warn('No se pudieron cargar las instancias públicas:', error));
      setProfile(savedProfile);
      setAccounts(savedAccounts);
      setSettings({ ...defaultSettings, ...savedSettings });
      setInstances(savedInstances);
    }).finally(() => {
      setBootProgress(100);
      window.setTimeout(() => setBooting(false), 350);
    });
    return () => { removeUpdateStatus(); removeUpdateProgress(); };
  }, []);
  const updateSetting = (key: string, value: string | boolean) => { const next = { ...settings, [key]: value }; setSettings(next); if (window.aether) void window.aether.saveSettings(next); };
  if (booting) return <div className="launcher-splash"><img src={logo} alt="Aether Studio" /><p>Preparando Aether Studio...</p><div className="splash-progress"><i style={{ width: `${bootProgress}%` }} /></div><small>Cargando datos, instancias y recursos</small></div>;
  return <div className={`app-shell ${settings.animations ? '' : 'no-animations'} ${settings.showBackgrounds ? '' : 'no-backgrounds'}`} style={{ '--accent': String(settings.accent) } as React.CSSProperties}>
    <header className="topbar"><div /><div className="topbar-actions"><button className="window-button" aria-label="Minimizar" onClick={() => window.aether?.minimize()}><img src={windowMinIcon} alt="" /></button><button className="window-button close" aria-label="Cerrar" onClick={() => window.aether?.close()}><img src={windowCloseIcon} alt="" /></button></div></header>
    <aside className="sidebar"><div><div className="brand"><img src={logo} alt="Aether Studio" /></div><nav className="main-nav">{navItems.map((item) => <button className={`nav-item ${page === item.id && !selectedInstance ? 'active' : ''}`} key={item.id} onClick={() => { setSelectedInstance(null); setPage(item.id); }}><img src={item.icon} alt="" />{item.label}</button>)}</nav>{(instances.length > 0 || cloudInstances.length > 0) && <div className="sidebar-instance-list"><div className="sidebar-instance-title">INSTANCIAS DISPONIBLES</div>{instances.map((instance) => <div className="sidebar-instance-row" key={instance.id} onContextMenu={(event) => { event.preventDefault(); setSidebarMenuId(instance.id); }}><button className={`sidebar-instance-link ${selectedInstance?.id === instance.id ? 'active' : ''}`} onClick={() => { setSidebarMenuId(null); setSelectedInstance(instance); }}><span className="sidebar-instance-icon">{instance.iconUrl ? <img src={instance.iconUrl} alt="" /> : '◇'}</span><span><strong>{instance.name}</strong><small>{instance.installed ? 'Instalado' : 'Descargar'}</small></span><i className={instance.installed ? 'ready' : ''} /></button>{sidebarMenuId === instance.id && <div className="sidebar-context-menu"><button onClick={() => setSelectedInstance(instance)}>Abrir instancia</button><button onClick={() => openSidebarFolder(instance)}>Abrir carpeta</button><button className="danger" onClick={() => deleteSidebarInstance(instance)}>Borrar instancia</button></div>}</div>)}{cloudInstances.map((instance) => <button className="sidebar-instance-link cloud-instance" key={instance.id} onClick={() => setAdminOpen(true)}><span className="sidebar-instance-icon">◇</span><span><strong>{instance.name}</strong><small>{instance.visibility === 'private' ? 'Privada' : 'Pública'} · v{instance.current_version}</small></span></button>)}</div>}</div><div className="account-area">{cloudRole === 'creator' && <button className="sign-out-button" onClick={() => setAdminOpen(true)}>Administración</button>}{profile && <button className="sign-out-button" onClick={() => { if (window.aether) void window.aether.clearProfile().then(() => { setProfile(null); setCloudRole(null); }); }}>Cerrar sesión</button>}<button className={`account-card ${profile ? 'signed-in' : ''}`} onClick={() => { if (!profile) setLoginOpen(true); }}>{profile && <img className="skin-head" src={skinHeadUrl(profile)} alt={`Skin de ${profile.name}`} />}<span className="online-dot" /><div><strong>{profile?.name ?? 'Sin sesión'}</strong><small>{profile ? cloudRole === 'creator' ? 'Creador verificado' : cloudRole === 'instance_admin' ? 'Administrador de instancia' : 'Minecraft Premium' : 'Inicia sesión para más funciones'}</small></div><img className="account-icon" src={userIcon} alt="" /></button></div></aside>
    <main className="content">{launcherUpdate.status === 'available' && <div className="launcher-update-banner"><strong>Actualización disponible</strong><span>Versión actual {launcherUpdate.current} · Nueva versión {launcherUpdate.available}</span><small>Descargando automáticamente: {Math.round(launcherUpdate.progress)}%</small></div>}{launcherUpdate.status === 'checking' && <div className="launcher-update-banner subtle">Comprobando actualizaciones del launcher...</div>}{selectedInstance ? <InstanceDetail instance={selectedInstance} onBack={() => setSelectedInstance(null)} onChanged={() => { if (window.aether) void window.aether.listInstances().then((next) => { setInstances(next); setSelectedInstance(next.find((item) => item.id === selectedInstance.id) ?? null); }); }} /> : page === 'home' ? <Home instances={instances} onCreate={() => setCreateOpen(true)} onChanged={refreshInstances} onSelect={setSelectedInstance} /> : page === 'instances' ? <Instances instances={instances} onCreate={() => setCreateOpen(true)} onChanged={refreshInstances} onSelect={setSelectedInstance} /> : <Settings profile={profile} settings={settings} updateSetting={updateSetting} onLogin={() => setLoginOpen(true)} onLogout={() => { if (window.aether) void window.aether.clearProfile().then(() => setProfile(null)); }} />}</main>
    {createOpen && <CreateModal onClose={() => { setCreateOpen(false); if (window.aether) void window.aether.listInstances().then(setInstances); }} />}
    {loginOpen && <MicrosoftLogin accounts={accounts} onClose={() => setLoginOpen(false)} onSelect={(selected) => { acceptProfile(selected); setLoginOpen(false); }} onSuccess={(signedInProfile) => { acceptProfile(signedInProfile); setAccounts((current) => [...current.filter((account) => account.id !== signedInProfile.id), signedInProfile]); setLoginOpen(false); }} />}
    {adminOpen && <AdminPanel instances={cloudInstances} role={cloudRole} onClose={() => setAdminOpen(false)} onChanged={() => void loadAvailableCloudInstances().then(setCloudInstances)} />}
  </div>;
}

function InstanceCards({ instances, onChanged, onSelect }: { instances: Instance[]; onChanged: () => void; onSelect: (instance: Instance) => void }) {
  const [menuId, setMenuId] = useState<string | null>(null);
  const [error, setError] = useState('');
  const openFolder = (instance: Instance) => { setMenuId(null); if (window.aether) void window.aether.openInstanceFolder(instance.id).catch((reason) => setError(reason instanceof Error ? reason.message : 'No se pudo abrir la carpeta.')); };
  const remove = (instance: Instance) => { setMenuId(null); if (!window.aether) return; void window.aether.deleteInstance(instance.id).then(onChanged).catch((reason) => setError(reason instanceof Error ? reason.message : 'No se pudo borrar la instancia.')); };
  return <div className="created-instance-grid">{error && <p className="instance-action-error">{error}</p>}{instances.map((instance) => <article className="created-instance-card" key={instance.id} onClick={() => onSelect(instance)} onContextMenu={(event) => { event.preventDefault(); setMenuId(instance.id); }}><div className="created-instance-icon">{instance.iconUrl ? <img src={instance.iconUrl} alt="" /> : '◇'}</div><div><strong>{instance.name}</strong><small>{instance.installed ? `${instance.version} · Instalado` : `${instance.version} · Descargar`}</small></div><span className={`instance-status-dot ${instance.installed ? 'ready' : 'pending'}`} />{menuId === instance.id && <div className="instance-context-menu" onClick={(event) => event.stopPropagation()}><button onClick={() => onSelect(instance)}>Abrir instancia</button><button onClick={() => openFolder(instance)}>Abrir carpeta</button><button className="danger" onClick={() => remove(instance)}>Borrar instancia</button></div>}</article>)}</div>;
}
function Home({ instances, onCreate, onChanged, onSelect }: { instances: Instance[]; onCreate: () => void; onChanged: () => void; onSelect: (instance: Instance) => void }) { return <div className="home"><section className="hero" style={{ backgroundImage: `url(${welcomeBackground})` }}><div className="hero-content"><p className="eyebrow">AETHER CLIENT</p><h1>Bienvenido a Aether Client</h1><p>Tu launcher para los mejores eventos de Minecraft.</p></div><div className="hero-tagline">Juega · Crea · Disfruta</div></section><div className="section-header"><h2>Tus instancias</h2><button className="text-button">Ver todas →</button></div>{instances.length ? <InstanceCards instances={instances} onChanged={onChanged} onSelect={onSelect} /> : <section className="empty-state"><div className="cube-icon"><img src={addIcon} alt="" /></div><h3>No tienes instancias todavía</h3><p>Crea tu primera instancia para comenzar<br />a jugar con tus amigos.</p><button className="secondary-button" onClick={onCreate}>＋ Crear instancia</button></section>}<section className="instance-footer"><span className="footer-crown">♕</span><div><strong>¿No encuentras tu instancia?</strong><small>Puedes crear una nueva o importar una desde un archivo.</small></div><div className="footer-actions"><button className="outline-button" onClick={onCreate}>＋ Crear instancia</button><button className="import-button">⇧ Importar</button></div></section></div>; }
function Instances({ instances, onCreate, onChanged, onSelect }: { instances: Instance[]; onCreate: () => void; onChanged: () => void; onSelect: (instance: Instance) => void }) { return <section className="page-panel empty-page"><div className="section-header"><div><h2>Instancias</h2><p className="muted">Crea y administra tus perfiles de Minecraft.</p></div><button className="primary-button compact" onClick={onCreate}>＋ Crear instancia</button></div>{instances.length ? <InstanceCards instances={instances} onChanged={onChanged} onSelect={onSelect} /> : <div className="empty-state"><div className="cube-icon">◇</div><h3>No tienes instancias todavía</h3><p>Crea tu primera instancia para comenzar a jugar.</p><button className="secondary-button" onClick={onCreate}>Crear instancia</button></div>}</section>; }
function InstanceDetail({ instance, onBack, onChanged }: { instance: Instance; onBack: () => void; onChanged: () => void }) {
  const [busy, setBusy] = useState(false);
  const [running, setRunning] = useState(false);
  const [gameReady, setGameReady] = useState(false);
  const [startedAt, setStartedAt] = useState(0);
  const [runtimeSeconds, setRuntimeSeconds] = useState(0);
  const [progress, setProgress] = useState(0);
  const [progressMessage, setProgressMessage] = useState('');
  const [hasUpdate, setHasUpdate] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => {
    if (!window.aether) return;
    void window.aether.isInstanceRunning(instance.id).then((status) => { setRunning(status.running); setGameReady(status.running && status.startedAt > 0); setStartedAt(status.startedAt); });
    return window.aether.onInstanceStatus((id, isRunning, launchStartedAt) => { if (id === instance.id) { setRunning(isRunning); setGameReady(isRunning && launchStartedAt > 0); setStartedAt(launchStartedAt); } });
  }, [instance.id]);
  useEffect(() => {
    if (!window.aether) return;
    void window.aether.hasInstanceUpdate(instance.id).then(setHasUpdate).catch(() => setHasUpdate(false));
    return window.aether.onInstanceProgress((id, percent, message) => { if (id === instance.id) { setProgress(percent); setProgressMessage(message); } });
  }, [instance.id]);
  useEffect(() => {
    if (!running) return;
    const timer = window.setInterval(() => setRuntimeSeconds(Math.max(0, Math.floor((Date.now() - startedAt) / 1000))), 1000);
    setRuntimeSeconds(Math.max(0, Math.floor((Date.now() - startedAt) / 1000)));
    return () => window.clearInterval(timer);
  }, [running, startedAt]);
  const install = () => { if (!window.aether || busy) return; setBusy(true); setProgress(0); setProgressMessage('Preparando descarga...'); setError(''); void window.aether.installInstance(instance.id).then(onChanged).catch((reason) => setError(reason instanceof Error ? reason.message : 'No se pudo instalar la instancia.')).finally(() => setBusy(false)); };
  const update = () => { if (!window.aether || busy) return; setBusy(true); setProgress(0); setProgressMessage('Buscando actualización...'); setError(''); void window.aether.updateInstance(instance.id).then(() => { setHasUpdate(false); onChanged(); }).catch((reason) => setError(reason instanceof Error ? reason.message : 'No se pudo actualizar la instancia.')).finally(() => setBusy(false)); };
  const play = () => { if (!window.aether) return; if (running) { void window.aether.stopInstance(instance.id).then(() => { setRunning(false); setGameReady(false); setStartedAt(0); setBusy(false); }).catch((reason) => setError(reason instanceof Error ? reason.message : 'No se pudo detener Minecraft.')); return; } setError(''); setRunning(true); setGameReady(false); setStartedAt(0); setBusy(true); setProgress(0); setProgressMessage('Iniciando Minecraft...'); void window.aether.launchInstance(instance.id).then(() => setBusy(false)).catch((reason) => { setRunning(false); setGameReady(false); setStartedAt(0); setBusy(false); setError(reason instanceof Error ? reason.message : 'No se pudo iniciar Minecraft.'); }); };
  const elapsed = startedAt && gameReady ? runtimeSeconds : 0;
  const elapsedText = `${String(Math.floor(elapsed / 3600)).padStart(2, '0')}:${String(Math.floor((elapsed % 3600) / 60)).padStart(2, '0')}:${String(elapsed % 60).padStart(2, '0')}`;
  const action = !instance.installed ? install : hasUpdate ? update : play;
  const actionLabel = busy ? (progressMessage || 'Preparando...') : running ? 'Detener' : !instance.installed ? 'Descargar' : hasUpdate ? 'Actualizar' : 'Jugar';
  return <section className="instance-detail"><button className="detail-back" onClick={onBack}>‹ Volver a instancias</button><div className="instance-detail-hero">{instance.iconUrl && <img src={instance.iconUrl} alt="" />}<div><p className="eyebrow">INSTANCIA DE MINECRAFT</p><h1>{instance.name}</h1><p>{instance.version} · Modrinth</p></div></div>{busy && <div className="install-progress"><strong>{instance.name}</strong><span>{progressMessage}</span><div><i style={{ width: `${Math.max(progress, 8)}%` }} /></div><small>{progress}% completado</small></div>}<div className="instance-detail-actions"><button className={`primary-button detail-play ${running ? 'stop-button' : ''}`} disabled={busy && !running} onClick={action}>{actionLabel}</button>{gameReady && <small className="instance-runtime">Minecraft abierto: {elapsedText}</small>}<button className="folder-button" onClick={() => window.aether?.openInstanceFolder(instance.id)}><img src={folderIcon} alt="" /> Abrir carpeta de la instancia</button></div>{error && <p className="instance-action-error">{error}</p>}<div className="instance-info-card"><h2>Detalles de la instancia</h2><p>Los mods, configuraciones, librerías y recursos del modpack se instalarán dentro de esta instancia.</p></div></section>;
}

const settingTabs = [{ label: 'General', icon: settingsIcon }, { label: 'Launcher', icon: launcherIcon }, { label: 'Minecraft', icon: minecraftIcon }, { label: 'Cuenta', icon: userIcon }, { label: 'Notificaciones', icon: notificationsIcon }, { label: 'Apariencia', icon: appearanceIcon }];

function Settings({ profile, settings, updateSetting, onLogin, onLogout }: { profile: { id: string; name: string; skinUrl?: string } | null; settings: SettingsState; updateSetting: (key: string, value: string | boolean) => void; onLogin: () => void; onLogout: () => void }) {
  const [active, setActive] = useState('General');
  const accent = String(settings.accent);
  const dark = settings.theme === 'Oscuro';
  const icon = settingTabs.find((tab) => tab.label === active)?.icon ?? settingsIcon;
  return <div className={`settings-page ${dark ? '' : 'light-theme'}`} style={{ '--accent': accent } as React.CSSProperties}>
    <header className="settings-heading"><img src={icon} alt="" /><div><h1>{active}</h1><p>Personaliza tu experiencia en Aether Studio</p></div></header>
    <div className="settings-layout"><aside className="settings-tabs">{settingTabs.map((tab) => <button className={active === tab.label ? 'selected' : ''} key={tab.label} onClick={() => setActive(tab.label)}><img src={tab.icon} alt="" />{tab.label}</button>)}</aside><div className="settings-grid"><SettingsContent active={active} settings={settings} updateSetting={updateSetting} profile={profile} onLogin={onLogin} onLogout={onLogout} /></div></div>
    <div className="help-bar"><span>ⓘ</span><div><strong>¿Necesitas ayuda?</strong><small>Consulta la documentación o únete a nuestro servidor de Discord para obtener soporte.</small></div><button onClick={() => window.alert('La documentación estará disponible próximamente.')}>▣ Documentación</button><button onClick={() => window.aether?.openDiscord()}><img src={discordIcon} alt="" /> Discord</button></div>
  </div>;
}

function SettingsContent({ active, settings, updateSetting, profile, onLogin, onLogout }: { active: string; settings: SettingsState; updateSetting: (key: string, value: string | boolean) => void; profile: { id: string; name: string; skinUrl?: string } | null; onLogin: () => void; onLogout: () => void }) {
  const select = (key: string, options: string[]) => <select value={String(settings[key])} onChange={(event) => updateSetting(key, event.target.value)}>{options.map((option) => <option key={option}>{option}</option>)}</select>;
  const toggle = (key: string) => <Toggle enabled={Boolean(settings[key])} onChange={(value) => updateSetting(key, value)} />;
  if (active === 'General') return <SettingsCard title={<><img src={settingsIcon} alt="" /> General</>}><SettingRow title="Idioma" description="Selecciona el idioma de la interfaz." control={select('language', ['Español', 'English'])} /><SettingRow title="Iniciar con Windows" description="Abre Aether Client automáticamente al iniciar Windows." control={toggle('startWithWindows')} /><SettingRow title="Minimizar en la bandeja" description="Mantén la aplicación en segundo plano al cerrarla." control={toggle('minimizeToTray')} /><SettingRow title="Comprobar actualizaciones" description="Recibe las últimas mejoras y correcciones." control={<button className="verify-button" onClick={() => window.alert('Aether Client está actualizado')}>⟳ Verificar ahora</button>} /></SettingsCard>;
  if (active === 'Launcher') return <SettingsCard title={<><img src={launcherIcon} alt="" /> Launcher</>}><SettingRow title="Ruta de Java" description="Java que se usará para ejecutar Minecraft." control={<InputControl value={String(settings.javaPath)} onChange={(value) => updateSetting('javaPath', value)} />} /><SettingRow title="Memoria RAM por defecto" description="Cantidad de RAM asignada a las instancias." control={select('defaultRam', ['4 GB', '6 GB', '8 GB'])} /><SettingRow title="Proceso de Java" description="Número de núcleos del procesador a usar." control={select('javaProcess', ['Automático', '4 núcleos'])} /><SettingRow title="Ubicación de instancias" description="Carpeta donde se guardan las instancias." control={<InputControl value={String(settings.instancesPath)} onChange={(value) => updateSetting('instancesPath', value)} />} /></SettingsCard>;
  if (active === 'Minecraft') return <SettingsCard title={<><img src={minecraftIcon} alt="" /> Minecraft</>}><SettingRow title="Versión de Java" description="Usada por todas las instancias." control={select('javaVersion', ['Java 17 (Recomendada)', 'Java 21'])} /><SettingRow title="Directorio del juego" description="Carpeta de instalación de Minecraft." control={<InputControl value={String(settings.gameDirectory)} onChange={(value) => updateSetting('gameDirectory', value)} />} /><SettingRow title="Permitir mods (Fabric / Forge)" description="Habilita la carga de mods en las instancias." control={toggle('allowMods')} /><SettingRow title="Instalar automáticamente librerías" description="Descarga las dependencias necesarias." control={toggle('autoLibraries')} /></SettingsCard>;
  if (active === 'Cuenta') return <SettingsCard title={<><img src={userIcon} alt="" /> Cuenta</>}><div className="account-settings">{profile ? <><img className="settings-skin" src={skinHeadUrl(profile)} alt={`Skin de ${profile.name}`} /><h3>{profile.name}</h3><p>Minecraft Premium</p><button className="secondary-button compact" onClick={onLogout}>Cerrar sesión</button></> : <><img src={userIcon} alt="" /><h3>Sin sesión iniciada</h3><p>Inicia sesión para sincronizar tus instancias y acceder a todas las funciones.</p><button className="primary-button compact" onClick={onLogin}>Iniciar sesión</button></>}</div></SettingsCard>;
  if (active === 'Notificaciones') return <SettingsCard title={<><img src={notificationsIcon} alt="" /> Notificaciones</>}><SettingRow title="Notificaciones del launcher" description="Muestra avisos importantes de Aether Client." control={toggle('launcherNotifications')} /><SettingRow title="Actualizaciones disponibles" description="Avisar cuando haya una nueva versión." control={toggle('availableUpdates')} /><SettingRow title="Eventos y novedades" description="Recibe noticias sobre eventos de Minecraft." control={toggle('eventsNews')} /></SettingsCard>;
  return <SettingsCard title={<><img src={appearanceIcon} alt="" /> Apariencia</>}><SettingRow title="Tema" description="Elige el estilo de la interfaz." control={select('theme', ['Oscuro', 'Claro'])} /><SettingRow title="Color de acento" description="Personaliza el color principal de la interfaz." control={<div className="colors">{[['#4c75ff','blue'],['#8739d1','purple'],['#d62c91','pink'],['#ed4e55','red'],['#f2c426','yellow'],['#36c968','green'],['#189dd7','cyan']].map(([color, name]) => <button aria-label={`Usar color ${name}`} className={`color ${name} ${settings.accent === color ? 'chosen' : ''}`} key={name} onClick={() => updateSetting('accent', color)} />)}</div>} /><SettingRow title="Mostrar fondos" description="Activa o desactiva los fondos en la biblioteca." control={toggle('showBackgrounds')} /><SettingRow title="Animaciones" description="Habilita las animaciones de la interfaz." control={toggle('animations')} /></SettingsCard>;
}

function SettingsCard({ title, children }: { title: React.ReactNode; children: React.ReactNode }) { return <section className="settings-card"><h2>{title}</h2>{children}</section>; }
function SettingRow({ title, description, control }: { title: string; description: string; control: React.ReactNode }) { return <div className="setting-row"><div><strong>{title}</strong><small>{description}</small></div>{control}</div>; }
function InputControl({ value, onChange }: { value: string; onChange: (value: string) => void }) { return <input className="input-control" value={value} onChange={(event) => onChange(event.target.value)} />; }
function Toggle({ enabled, onChange }: { enabled: boolean; onChange: (value: boolean) => void }) { return <button aria-label="Alternar opción" className={`toggle ${enabled ? 'on' : ''}`} onClick={() => onChange(!enabled)}><i /></button>; }
function CreateModal({ onClose }: { onClose: () => void }) {
  const [name, setName] = useState('Mi nueva instancia');
  const [version, setVersion] = useState('Última versión (1.21.4)');
  const [minecraftVersions, setMinecraftVersions] = useState<{ id: string; type: string }[]>([]);
  const [loader, setLoader] = useState('vanilla');
  const [loaderVersions, setLoaderVersions] = useState<{ version: string }[]>([]);
  const [loaderVersion, setLoaderVersion] = useState('');
  const [icon, setIcon] = useState('grass');
  const [background, setBackground] = useState('sky');
  const [ram, setRam] = useState('4 GB');
  const [processor, setProcessor] = useState('Automático');
  const [java, setJava] = useState('Java 17 (Recomendada)');
  const [instancePath, setInstancePath] = useState('C:\\AetherStudio\\instances\\Mi nueva instancia');
  const [mods, setMods] = useState(true);
  const [libraries, setLibraries] = useState(true);
  const [advanced, setAdvanced] = useState(false);
  const [customIcon, setCustomIcon] = useState<string | null>(null);
  const [modpackQuery, setModpackQuery] = useState('');
  const [modpacks, setModpacks] = useState<{ id: string; title: string; description: string; version: string; iconUrl?: string; downloads: number; source: 'Modrinth' }[]>([]);
  const [modpackLoading, setModpackLoading] = useState(true);
  const [modpackError, setModpackError] = useState('');
  const [modpackHasMore, setModpackHasMore] = useState(false);
  const [importedPack, setImportedPack] = useState<string | null>(null);
  const [creatingInstance, setCreatingInstance] = useState(false);
  const [createError, setCreateError] = useState('');
  const icons: [string, string, string][] = [['heart', 'Corazón', heartIcon], ['sword', 'Espada', swordIcon], ['apple', 'Manzana dorada', appleIcon]];
  const imageAsDataUrl = async (source: string) => {
    const response = await fetch(source);
    const blob = await response.blob();
    return await new Promise<string>((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result)); reader.onerror = () => reject(reader.error); reader.readAsDataURL(blob); });
  };
  const createVanilla = async () => {
    if (!window.aether || creatingInstance || !name.trim()) return;
    setCreatingInstance(true);
    setCreateError('');
    try {
      const selectedImage = customIcon && icon === 'custom' ? customIcon : icons.find(([key]) => key === icon)?.[2];
      await window.aether.createVanillaInstance(name.trim(), version, selectedImage ? await imageAsDataUrl(selectedImage) : null, background, loader, loaderVersion);
      onClose();
    } catch (error) {
      setCreateError(error instanceof Error ? error.message : 'No se pudo crear la instancia.');
    } finally {
      setCreatingInstance(false);
    }
  };
  useEffect(() => {
    if (!window.aether) return;
    void window.aether.getMinecraftVersions().then((items) => {
      setMinecraftVersions(items);
      if (items[0] && version.startsWith('Última')) setVersion(items[0].id);
    }).catch(() => setCreateError('No se pudieron cargar las versiones de Minecraft.'));
  }, []);
  useEffect(() => {
    if (!window.aether || loader === 'vanilla') { setLoaderVersions([]); setLoaderVersion(''); return; }
    void window.aether.getLoaderVersions(loader, version).then((items) => { setLoaderVersions(items); setLoaderVersion(items[0]?.version ?? ''); }).catch(() => { setLoaderVersions([]); setLoaderVersion(''); });
  }, [loader, version]);
  useEffect(() => {
    if (!window.aether) return;
    setModpackLoading(true);
    setModpackError('');
    void window.aether.searchModpacks(modpackQuery).then((result) => { setModpacks(result.items); setModpackHasMore(result.hasMore); }).catch(() => setModpackError('No se pudieron cargar los modpacks de la comunidad.')).finally(() => setModpackLoading(false));
  }, [modpackQuery]);
  const selectModpack = async (pack: { id: string; title: string; version: string; iconUrl?: string }) => {
    if (!window.aether || creatingInstance) return;
    setCreatingInstance(true);
    setCreateError('');
    setName(pack.title);
    setVersion(pack.version);
    try {
      await window.aether.createInstanceFromModpack(pack.id, pack.title, customIcon, pack.iconUrl, background);
      onClose();
    } catch (error) {
      setCreateError(error instanceof Error ? error.message : 'No se pudo crear la instancia.');
    } finally {
      setCreatingInstance(false);
    }
  };
  return <div className="modal-backdrop creator-backdrop" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
    <div className="instance-creator">
      <header className="creator-header"><button className="creator-back" onClick={onClose}>‹</button><span className="creator-cube">◇</span><div><h2>Crear instancia</h2><p>Configura y personaliza tu nueva instancia de Minecraft</p></div><button className="modal-close" onClick={onClose}>×</button></header>
      <div className="creator-columns">
        <div className="creator-main">
          <section className="creator-card"><h3><b>1</b>Información básica</h3><div className="creator-basic"><label>Nombre de la instancia<input value={name} maxLength={32} onChange={(event) => setName(event.target.value)} autoFocus /><small>{name.length}/32</small></label><div><span className="creator-label">Icono</span><div className="icon-picker">{icons.map(([key, label, image]) => <button title={label} className={icon === key ? 'chosen' : ''} key={key} onClick={() => { setIcon(key); setCustomIcon(null); }}><img src={customIcon && icon === key ? customIcon : image} alt={label} /></button>)}<button className="icon-more" onClick={() => { if (window.aether) void window.aether.selectCustomIcon().then((selected) => { if (selected) { setCustomIcon(selected); setIcon('custom'); } }); }}>＋</button></div>{customIcon && <small className="custom-icon-name">Icono personalizado seleccionado</small>}</div></div><div className="creator-preview"><span className="creator-label">Vista previa</span><div className={`creator-preview-card ${background}`}><div className="creator-preview-icon"><img src={customIcon && icon === 'custom' ? customIcon : icons.find(([key]) => key === icon)?.[2] ?? heartIcon} alt="" /></div><strong>{name || 'Mi instancia'}</strong><small>Vista previa de la instancia</small></div></div><div className="creator-background-picker"><span className="creator-label">Fondo</span><div>{[['sky', 'Celeste'], ['green', 'Verde'], ['purple', 'Morado']].map(([key, label]) => <button type="button" title={label} className={`background-option ${key} ${background === key ? 'chosen' : ''}`} key={key} onClick={() => setBackground(key)} />)}</div></div></section>
          <section className="creator-card"><h3><b>2</b>Versión y loader</h3><p className="creator-description">Elige una versión completa y estable de Minecraft y el loader que utilizará la instancia.</p><select value={version} onChange={(event) => setVersion(event.target.value)}>{minecraftVersions.length ? minecraftVersions.map((item) => <option value={item.id} key={item.id}>{item.id}</option>) : <option value="1.21.4">Cargando versiones estables...</option>}</select><div className="loader-grid"><label className="creator-field">Loader<select value={loader} onChange={(event) => setLoader(event.target.value)}><option value="vanilla">Vanilla</option><option value="fabric">Fabric</option><option value="neoforge">NeoForge</option><option value="forge">Forge</option></select></label><label className="creator-field">Versión del loader<select value={loaderVersion} disabled={loader === 'vanilla' || !loaderVersions.length} onChange={(event) => setLoaderVersion(event.target.value)}><option value="">{loader === 'vanilla' ? 'No aplica' : loaderVersions.length ? 'Selecciona una versión' : 'Cargando...'}</option>{loaderVersions.map((item) => <option value={item.version} key={item.version}>{item.version}</option>)}</select></label></div></section>
          <section className="creator-card modpack-section"><h3><b>3</b>Modpack <em>(opcional)</em></h3><p className="creator-description">Explora modpacks de la comunidad en Modrinth o importa un archivo .mrpack</p><div className="creator-tabs"><button className="active">Modrinth</button><button onClick={() => window.aether?.openExternal('https://www.curseforge.com/minecraft/search?class=mc-mods&search=modpack')}>CurseForge ↗</button><button onClick={() => { if (window.aether) void window.aether.importMrpack().then((pack) => { if (pack) { setImportedPack(pack.name); setName(pack.name); } }); }}>Importar .mrpack</button></div><div className="modpack-toolbar"><input value={modpackQuery} onChange={(event) => setModpackQuery(event.target.value)} placeholder="⌕  Buscar modpacks de la comunidad..." /><select defaultValue="relevance"><option value="relevance">Más relevantes</option><option value="downloads">Más descargados</option></select></div>{importedPack && <div className="imported-pack">✓ Modpack importado: <strong>{importedPack}</strong></div>}{createError && <div className="imported-pack create-error">{createError}</div>}{modpackLoading && <p className="modpack-status">Cargando modpacks de Modrinth...</p>}{modpackError && <p className="modpack-status error">{modpackError}</p>}<div className="modpack-grid">{modpacks.map((pack) => <article className="modpack-card" key={pack.id}><div className="modpack-image">{pack.iconUrl ? <img src={pack.iconUrl} alt="" loading="lazy" /> : '◇'}</div><div className="modpack-card-content"><strong>{pack.title} <i /></strong><small>{pack.version}</small><span>Modrinth · {pack.downloads.toLocaleString()} descargas</span><button disabled={creatingInstance} onClick={() => void selectModpack(pack)}>{creatingInstance ? 'Instalando...' : 'Seleccionar'}</button></div></article>)}<article className="custom-modpack"><b>＋</b><strong>Crear modpack personalizado</strong><small>Configura tus propios mods, recursos<br />y ajustes.</small><button>Crear</button></article></div>{modpackHasMore && <button className="load-more-modpacks" disabled={modpackLoading || creatingInstance} onClick={() => { if (!window.aether) return; setModpackLoading(true); void window.aether.searchModpacks(modpackQuery, modpacks.length).then((result) => { setModpacks((current) => [...current, ...result.items]); setModpackHasMore(result.hasMore); }).catch(() => setModpackError('No se pudieron cargar más modpacks.')).finally(() => setModpackLoading(false)); }}>Cargar más modpacks</button>}</section>
        </div>
        <aside className="creator-side"><section className="creator-card configuration"><h3><b>4</b>Configuración</h3><CreatorSelect label="RAM" description="Selecciona la cantidad de RAM asignada" value={ram} onChange={setRam} options={['2 GB', '4 GB', '6 GB', '8 GB']} /><CreatorSelect label="Procesador" description="Número de núcleos del procesador a usar" value={processor} onChange={setProcessor} options={['Automático', '4 núcleos', '8 núcleos']} /><CreatorSelect label="Java" description="Versión de Java" value={java} onChange={setJava} options={['Java 17 (Recomendada)', 'Java 21']} /><label className="creator-field">Carpeta de la instancia<small>Ruta donde se guardarán los archivos</small><input value={instancePath} onChange={(event) => setInstancePath(event.target.value)} /></label><CreatorToggle label="Permitir mods (Fabric / Forge)" description="Habilita la carga de mods en la instancia." enabled={mods} onChange={setMods} /><CreatorToggle label="Instalar automáticamente librerías" description="Descarga las dependencias necesarias." enabled={libraries} onChange={setLibraries} /><button className="advanced-toggle" onClick={() => setAdvanced(!advanced)}>◉ Configuración avanzada <span>{advanced ? '⌃' : '›'}</span></button>{advanced && <div className="advanced-content">Argumentos JVM y opciones avanzadas disponibles para esta instancia.</div>}        <button className="create-instance-button" disabled={creatingInstance} onClick={() => void createVanilla()}>{creatingInstance ? 'Creando...' : '◇ Crear instancia'}</button></section></aside>
      </div>
    </div>
  </div>;
}
function CreatorSelect({ label, description, value, onChange, options }: { label: string; description: string; value: string; onChange: (value: string) => void; options: string[] }) { return <label className="creator-field">{label}<small>{description}</small><select value={value} onChange={(event) => onChange(event.target.value)}>{options.map((option) => <option key={option}>{option}</option>)}</select></label>; }
function CreatorToggle({ label, description, enabled, onChange }: { label: string; description: string; enabled: boolean; onChange: (value: boolean) => void }) { return <div className="creator-toggle"><span>◉</span><label>{label}<small>{description}</small></label><button className={`toggle ${enabled ? 'on' : ''}`} onClick={() => onChange(!enabled)}><i /></button></div>; }

function MicrosoftLogin({ accounts, onClose, onSelect, onSuccess }: { accounts: { id: string; name: string; skinUrl?: string }[]; onClose: () => void; onSelect: (profile: { id: string; name: string; skinUrl?: string }) => void; onSuccess: (profile: { id: string; name: string; skinUrl?: string }) => void }) {
  const [step, setStep] = useState<'start' | 'code' | 'loading' | 'error'>('start');
  const [device, setDevice] = useState<{ deviceCode: string; userCode: string; verificationUri: string; interval: number }>();
  const [error, setError] = useState('');
  const start = async () => {
    setError('');
    try { const result = await window.aether?.startMicrosoftLogin(); if (!result) throw new Error('Electron no está disponible.'); setDevice(result); setStep('code'); } catch (reason) { setError(reason instanceof Error ? reason.message : 'No se pudo iniciar el acceso.'); setStep('error'); }
  };
  const finish = async () => {
    if (!device) return;
    setStep('loading');
    try { const profile = await window.aether?.finishMicrosoftLogin(device.deviceCode, device.interval); if (!profile) throw new Error('No se recibió el perfil de Minecraft.'); onSuccess(profile); } catch (reason) { setError(reason instanceof Error ? reason.message : 'No se pudo validar la cuenta.'); setStep('error'); }
  };
  const selectSaved = (account: { id: string; name: string; skinUrl?: string }) => { if (window.aether) void window.aether.activateProfile(account.id).then(onSelect); };
  return <div className="modal-backdrop" onMouseDown={(event) => event.target === event.currentTarget && onClose()}><div className="modal login-modal"><div className="modal-header"><div><h2>Iniciar sesión</h2><p>Usa tu cuenta Microsoft con Minecraft Premium.</p></div><button className="modal-close" onClick={onClose}>×</button></div>{step === 'start' && <>{accounts.length > 0 && <div className="saved-accounts"><strong>Cuentas guardadas</strong>{accounts.map((account) => <button key={account.id} onClick={() => selectSaved(account)}><img src={account.skinUrl ?? `https://mc-heads.net/avatar/${encodeURIComponent(account.name)}/32`} alt="" /><span>{account.name}<small>Minecraft Premium</small></span></button>)}</div>}<div className="microsoft-mark"><img src={microsoftIcon} alt="Microsoft" /></div><p className="login-copy">El inicio de sesión se realiza en la página oficial de Microsoft. No compartas tu contraseña con Aether Studio.</p><button className="primary-button login-button" onClick={start}><img src={microsoftIcon} alt="" /> Iniciar sesión con Microsoft</button></>}{step === 'code' && device && <><p className="login-copy">Se abrió Microsoft en tu navegador. Introduce este código para vincular tu cuenta:</p><strong className="device-code">{device.userCode}</strong><button className="secondary-button login-button" onClick={() => window.aether?.openMicrosoft(device.verificationUri)}>Abrir navegador de nuevo</button><button className="primary-button login-button" onClick={finish}>Ya inicié sesión</button></>}{step === 'loading' && <p className="login-copy">Validando tu cuenta Microsoft y tu licencia de Minecraft Premium...</p>}{step === 'error' && <><p className="login-error">{error}</p><button className="primary-button login-button" onClick={start}>Intentar de nuevo</button></>}</div></div>;
}

function AdminPanel({ instances, role, onClose, onChanged }: { instances: CloudInstance[]; role: 'creator' | 'instance_admin' | 'player' | null; onClose: () => void; onChanged: () => void }) {
  const [selectedId, setSelectedId] = useState(instances[0]?.id ?? '');
  const selected = instances.find((instance) => instance.id === selectedId);
  const [name, setName] = useState(selected?.name ?? '');
  const [description, setDescription] = useState(selected?.description ?? '');
  const [visibility, setVisibility] = useState<'public' | 'private'>(selected?.visibility ?? 'private');
  const [members, setMembers] = useState<{ user_id: string; role: string; profiles?: { minecraft_name?: string } }[]>([]);
  const [audit, setAudit] = useState<{ id: number; action: string; created_at: string; profiles?: { minecraft_name?: string } }[]>([]);
  const [memberUuid, setMemberUuid] = useState('');
  const [message, setMessage] = useState('');
  useEffect(() => {
    if (!selected) return;
    setName(selected.name); setDescription(selected.description); setVisibility(selected.visibility);
    void Promise.all([loadInstanceMembers(selected.id), loadInstanceAudit(selected.id)]).then(([nextMembers, nextAudit]) => {
      setMembers(nextMembers as typeof members);
      setAudit(nextAudit as typeof audit);
    }).catch((error: unknown) => setMessage(error instanceof Error ? error.message : 'No se pudo cargar la administración.'));
  }, [selectedId]);
  if (role !== 'creator' && role !== 'instance_admin') return null;
  const save = async () => {
    if (!selected) return;
    try { await updateCloudInstance(selected.id, { name, description, visibility }); setMessage('Cambios publicados.'); onChanged(); } catch (error) { setMessage(error instanceof Error ? error.message : 'No se pudieron publicar los cambios.'); }
  };
  const addMember = async () => {
    if (!selected || role !== 'creator' || !memberUuid.trim()) return;
    try { await addInstanceMember(selected.id, memberUuid.trim()); setMemberUuid(''); setMessage('Administrador añadido.'); setMembers(await loadInstanceMembers(selected.id) as typeof members); } catch (error) { setMessage(error instanceof Error ? error.message : 'No se pudo añadir el administrador.'); }
  };
  return <div className="modal-backdrop"><section className="modal admin-modal"><header className="modal-header"><div><h2>Administración de instancias</h2><p>Las acciones se validan en Supabase mediante RLS.</p></div><button className="modal-close" onClick={onClose}>×</button></header>{!instances.length ? <p className="login-copy">No hay instancias publicadas en la nube.</p> : <><label className="creator-field">Instancia<select value={selectedId} onChange={(event) => setSelectedId(event.target.value)}>{instances.map((instance) => <option value={instance.id} key={instance.id}>{instance.name} · {instance.visibility}</option>)}</select></label><label className="creator-field">Nombre<input value={name} onChange={(event) => setName(event.target.value)} disabled={role !== 'creator' && !selected} /></label><label className="creator-field">Descripción<textarea value={description} onChange={(event) => setDescription(event.target.value)} /></label><label className="creator-field">Visibilidad<select value={visibility} onChange={(event) => setVisibility(event.target.value as 'public' | 'private')}><option value="public">Pública</option><option value="private">Privada</option></select></label><button className="primary-button compact" onClick={() => void save()}>Publicar cambios</button><h3>Administradores autorizados</h3>{role === 'creator' && <div className="admin-member-add"><input placeholder="UUID de Minecraft" value={memberUuid} onChange={(event) => setMemberUuid(event.target.value)} /><button className="secondary-button compact" onClick={() => void addMember()}>Añadir</button></div>}<div className="admin-list">{members.map((member) => <div key={member.user_id}>{member.profiles?.minecraft_name ?? member.user_id} <small>Administrador</small></div>)}</div><h3>Historial</h3><div className="admin-audit">{audit.map((entry) => <div key={entry.id}>[{new Date(entry.created_at).toLocaleString()}] {entry.profiles?.minecraft_name ?? 'Usuario'}: {entry.action}</div>)}</div></>}{message && <p className="imported-pack">{message}</p>}</section></div>;
}

export default App;
