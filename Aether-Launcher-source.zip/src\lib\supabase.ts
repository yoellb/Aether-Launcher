import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const publishableKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string | undefined;

export const supabase = url && publishableKey ? createClient(url, publishableKey, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false },
}) : null;

export async function startCloudSession() {
  if (!supabase) return null;
  const { data: existing } = await supabase.auth.getSession();
  if (existing.session) return existing.session;
  const { data, error } = await supabase.auth.signInAnonymously();
  if (error) throw error;
  return data.session;
}

export async function loadPublicInstances() {
  if (!supabase) return [];
  const { data, error } = await supabase.from('instances').select('*').eq('visibility', 'public').order('updated_at', { ascending: false });
  if (error) throw error;
  return data;
}

export async function syncMinecraftIdentity(minecraftUuid: string, minecraftName: string) {
  if (!supabase) return;
  const { data: session } = await supabase.auth.getSession();
  if (!session.session) return;
  const { error } = await supabase.from('profiles').update({
    minecraft_uuid: minecraftUuid,
    minecraft_name: minecraftName,
    last_seen_at: new Date().toISOString(),
  }).eq('id', session.session.user.id);
  if (error) throw error;
}

export async function loadCloudProfile(): Promise<{ role: 'creator' | 'instance_admin' | 'player' } | null> {
  if (!supabase) return null;
  const { data: session } = await supabase.auth.getSession();
  if (!session.session) return null;
  const { data, error } = await supabase.from('profiles').select('role').eq('id', session.session.user.id).maybeSingle();
  if (error) throw error;
  return data as { role: 'creator' | 'instance_admin' | 'player' } | null;
}

export type CloudInstance = {
  id: string; name: string; description: string; visibility: 'public' | 'private';
  minecraft_version: string; loader: string; loader_version: string | null;
  current_version: number; manifest: Record<string, unknown>; updated_at: string;
};

export async function loadAvailableCloudInstances() {
  if (!supabase) return [] as CloudInstance[];
  const { data, error } = await supabase.from('instances').select('*').order('updated_at', { ascending: false });
  if (error) throw error;
  return (data ?? []) as CloudInstance[];
}

export async function updateCloudInstance(id: string, changes: Partial<Pick<CloudInstance, 'name' | 'description' | 'visibility' | 'minecraft_version' | 'loader' | 'loader_version'>>) {
  if (!supabase) throw new Error('Supabase no está configurado.');
  const { data, error } = await supabase.from('instances').update(changes).eq('id', id).select().single();
  if (error) throw error;
  return data as CloudInstance;
}

export async function loadInstanceMembers(instanceId: string) {
  if (!supabase) return [];
  const { data, error } = await supabase.from('instance_members').select('instance_id,user_id,role,created_at,profiles(minecraft_name,minecraft_uuid)').eq('instance_id', instanceId);
  if (error) throw error;
  return data ?? [];
}

export async function addInstanceMember(instanceId: string, minecraftUuid: string) {
  if (!supabase) throw new Error('Supabase no está configurado.');
  const { data: profile, error: profileError } = await supabase.from('profiles').select('id').eq('minecraft_uuid', minecraftUuid).single();
  if (profileError) throw profileError;
  const { error } = await supabase.from('instance_members').insert({ instance_id: instanceId, user_id: profile.id, role: 'instance_admin' });
  if (error) throw error;
}

export async function loadInstanceAudit(instanceId: string) {
  if (!supabase) return [];
  const { data, error } = await supabase.from('audit_log').select('*,profiles(minecraft_name)').eq('instance_id', instanceId).order('created_at', { ascending: false }).limit(100);
  if (error) throw error;
  return data ?? [];
}
