import { app, BrowserWindow, dialog, ipcMain, safeStorage, shell } from 'electron';
import { autoUpdater } from 'electron-updater';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { access } from 'node:fs/promises';
import { execFile } from 'node:child_process';
import type { ChildProcess } from 'node:child_process';
import { promisify } from 'node:util';
import { randomUUID } from 'node:crypto';
import { Client as MinecraftClient } from 'minecraft-launcher-core';
import { promises as fs } from 'node:fs';
import AdmZip from 'adm-zip';

const isDev = !app.isPackaged;
type MinecraftDownloadHandler = {
  downloadAsync: (url: string, directory: string, name: string, retry: boolean, type: string) => Promise<unknown>;
};
const minecraftHandler = (require('minecraft-launcher-core/components/handler') as { prototype: MinecraftDownloadHandler }).prototype;
const originalMinecraftDownload = minecraftHandler.downloadAsync;
let activeMinecraftDownloads = 0;
const minecraftDownloadQueue: (() => void)[] = [];
function queueMinecraftDownload(task: () => Promise<unknown>) {
  return new Promise<unknown>((resolve, reject) => {
    const run = () => {
      activeMinecraftDownloads += 1;
      void task().then(resolve, reject).finally(() => {
        activeMinecraftDownloads -= 1;
        minecraftDownloadQueue.shift()?.();
      });
    };
    if (activeMinecraftDownloads < 2) run();
    else minecraftDownloadQueue.push(run);
  });
}
minecraftHandler.downloadAsync = function (url, directory, name, retry, type) {
  return queueMinecraftDownload(() => originalMinecraftDownload.call(this, url, directory, name, retry, type));
};
const execFileAsync = promisify(execFile);
const microsoftClientId = 'ba6ffc07-a9b4-41e2-bff8-a330b97c3eac';
const profilePath = () => path.join(app.getPath('userData'), 'minecraft-accounts.json');
const settingsPath = () => path.join(app.getPath('userData'), 'settings.json');
const instancesPath = () => path.join(app.getPath('userData'), 'instances.json');
const runningInstances = new Map<string, { child?: ChildProcess; startedAt: number }>();
const launchingInstances = new Set<string>();
const cancelledLaunches = new Set<string>();
type MinecraftProfile = { id: string; name: string; skinUrl?: string; accessToken?: string; accessTokenEncrypted?: string; clientToken?: string };
type AccountStore = { accounts: MinecraftProfile[]; activeId: string | null };
type LauncherSettings = Record<string, string | boolean>;
type CommunityModpack = { id: string; title: string; description: string; version: string; iconUrl?: string; downloads: number; source: 'Modrinth' };
type CreatedInstance = { id: string; name: string; path: string; version: string; minecraftVersion?: string; loader?: string; loaderVersion?: string; modpackId: string; packUrl?: string; iconPath?: string; iconUrl?: string; background?: string; installed?: boolean; createdAt: string };
async function readInstances(): Promise<CreatedInstance[]> {
  try {
    const instances = JSON.parse(await fs.readFile(instancesPath(), 'utf8')) as CreatedInstance[];
    const unique = Array.from(new Map(instances.map((instance) => [instance.id, instance])).values());
    if (unique.length !== instances.length) await writeInstances(unique);
    return unique;
  }
  catch (error) { if ((error as NodeJS.ErrnoException).code === 'ENOENT') return []; throw error; }
}
async function writeInstances(instances: CreatedInstance[]) {
  await fs.mkdir(app.getPath('userData'), { recursive: true });
  await fs.writeFile(instancesPath(), JSON.stringify(instances), 'utf8');
}
async function readAccounts(): Promise<AccountStore> {
  try {
    const store = JSON.parse(await fs.readFile(profilePath(), 'utf8')) as AccountStore;
    return { ...store, accounts: store.accounts.map((account) => ({ ...account, accessToken: account.accessToken ?? (account.accessTokenEncrypted && safeStorage.isEncryptionAvailable() ? safeStorage.decryptString(Buffer.from(account.accessTokenEncrypted, 'base64')) : undefined) })) };
  }
  catch (error) { if ((error as NodeJS.ErrnoException).code === 'ENOENT') return { accounts: [], activeId: null }; throw error; }
}
async function writeAccounts(store: AccountStore) {
  await fs.mkdir(app.getPath('userData'), { recursive: true });
  const accounts = store.accounts.map(({ accessToken, accessTokenEncrypted, ...account }) => ({ ...account, ...(accessToken && safeStorage.isEncryptionAvailable() ? { accessTokenEncrypted: safeStorage.encryptString(accessToken).toString('base64') } : { accessToken, accessTokenEncrypted }) }));
  await fs.writeFile(profilePath(), JSON.stringify({ ...store, accounts }), 'utf8');
}
async function readSettings(): Promise<LauncherSettings> {
  try { return JSON.parse(await fs.readFile(settingsPath(), 'utf8')) as LauncherSettings; }
  catch (error) { if ((error as NodeJS.ErrnoException).code === 'ENOENT') return {}; throw error; }
}
async function writeSettings(settings: LauncherSettings) {
  await fs.mkdir(app.getPath('userData'), { recursive: true });
  await fs.writeFile(settingsPath(), JSON.stringify(settings), 'utf8');
}
async function searchCommunityModpacks(query: string, offset = 0): Promise<{ items: CommunityModpack[]; hasMore: boolean }> {
  const params = new URLSearchParams({ query, facets: JSON.stringify([['project_type:modpack']]), limit: '100', offset: String(offset), index: 'relevance' });
  const result = await requestJson<{ hits: { project_id: string; title: string; description: string; latest_version?: string; icon_url?: string; downloads: number }[]; total_hits: number }>(`https://api.modrinth.com/v2/search?${params}`, { headers: { 'User-Agent': 'AetherClient/1.0' } });
  return { items: result.hits.map((hit) => ({ id: hit.project_id, title: hit.title, description: hit.description, version: hit.latest_version ?? 'Versión disponible', iconUrl: hit.icon_url, downloads: hit.downloads, source: 'Modrinth' })), hasMore: offset + result.hits.length < result.total_hits };
}
async function importMrpack(): Promise<{ name: string; path: string } | null> {
  const result = await dialog.showOpenDialog({ properties: ['openFile'], filters: [{ name: 'Modrinth modpack', extensions: ['mrpack'] }] });
  if (result.canceled || result.filePaths.length === 0) return null;
  const sourcePath = result.filePaths[0];
  const destinationDir = path.join(app.getPath('userData'), 'imported-modpacks');
  await fs.mkdir(destinationDir, { recursive: true });
  const destinationPath = path.join(destinationDir, path.basename(sourcePath));
  await fs.copyFile(sourcePath, destinationPath);
  return { name: path.basename(sourcePath, '.mrpack'), path: destinationPath };
}
async function selectCustomIcon(): Promise<string | null> {
  const result = await dialog.showOpenDialog({ properties: ['openFile'], filters: [{ name: 'Imágenes', extensions: ['png', 'jpg', 'jpeg', 'webp'] }] });
  if (result.canceled || result.filePaths.length === 0) return null;
  const filePath = result.filePaths[0];
  const extension = path.extname(filePath).toLowerCase().replace('.', '');
  const mime = extension === 'jpg' || extension === 'jpeg' ? 'image/jpeg' : `image/${extension}`;
  return `data:${mime};base64,${(await fs.readFile(filePath)).toString('base64')}`;
}
function safeRelativePath(relativePath: string) {
  const normalized = path.normalize(relativePath);
  if (path.isAbsolute(normalized) || normalized === '..' || normalized.startsWith(`..${path.sep}`)) throw new Error('El modpack contiene una ruta de archivo no válida.');
  return normalized;
}
async function downloadFile(url: string): Promise<Buffer> {
  const response = await fetch(url, { headers: { 'User-Agent': 'AetherClient/1.0' } });
  if (!response.ok) throw new Error(`No se pudo descargar ${url} (${response.status}).`);
  return Buffer.from(await response.arrayBuffer());
}
async function createCommunityInstance(modpackId: string, name: string, customIcon?: string | null, modpackIconUrl?: string, background = 'sky'): Promise<CreatedInstance> {
  const versions = await requestJson<{ version_number: string; files: { url: string; filename: string; primary?: boolean }[] }[]>(`https://api.modrinth.com/v2/project/${encodeURIComponent(modpackId)}/version`, { headers: { 'User-Agent': 'AetherClient/1.0' } });
  const version = versions[0];
  if (!version) throw new Error('Este modpack no tiene una versión publicada.');
  const packFile = version.files.find((file) => file.filename.toLowerCase().endsWith('.mrpack')) ?? version.files.find((file) => file.primary) ?? version.files[0];
  if (!packFile) throw new Error('No se encontró el archivo descargable del modpack.');
  const root = path.join(app.getPath('userData'), 'instances', `${Date.now()}-${name.replace(/[<>:"/\\|?*]/g, '_')}`);
  await fs.mkdir(root, { recursive: true });
  let iconPath: string | undefined;
  if (customIcon?.startsWith('data:')) {
    const match = customIcon.match(/^data:image\/([a-z0-9+.-]+);base64,(.+)$/i);
    if (match) { iconPath = path.join(root, `icon.${match[1]}`); await fs.writeFile(iconPath, Buffer.from(match[2], 'base64')); }
  }
  if (!iconPath && modpackIconUrl) {
    const extension = path.extname(new URL(modpackIconUrl).pathname).toLowerCase() || '.png';
    iconPath = path.join(root, `icon${extension}`);
    await fs.writeFile(iconPath, await downloadFile(modpackIconUrl));
  }
  const created = { id: path.basename(root), name, path: root, version: version.version_number, modpackId, packUrl: packFile.url, iconPath, background, installed: false, createdAt: new Date().toISOString() };
  await writeInstances([...(await readInstances()), created]);
  return created;
}
async function getMinecraftVersions() {
  const manifest = await requestJson<{ versions: { id: string; type: string }[] }>('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json', { headers: { 'User-Agent': 'AetherClient/1.0' } });
  return manifest.versions.filter((version) => version.type === 'release');
}
async function getLoaderVersions(loader: string, minecraftVersion: string) {
  if (loader === 'vanilla') return [];
  if (loader === 'fabric') {
    const versions = await requestJson<{ loader: { version: string } }[]>(`https://meta.fabricmc.net/v2/versions/loader/${encodeURIComponent(minecraftVersion)}`, { headers: { 'User-Agent': 'AetherClient/1.0' } });
    return versions.map((item) => ({ version: item.loader.version }));
  }
  if (loader === 'forge') {
    const metadata = await requestJson<Record<string, string[]>>('https://files.minecraftforge.net/net/minecraftforge/forge/maven-metadata.json', { headers: { 'User-Agent': 'AetherClient/1.0' } });
    return (metadata[minecraftVersion] ?? []).reverse().map((version) => ({ version }));
  }
  const xml = await requestText('https://maven.neoforged.net/releases/net/neoforged/neoforge/maven-metadata.xml', { headers: { 'User-Agent': 'AetherClient/1.0' } });
  const versions = [...xml.matchAll(/<version>([^<]+)<\/version>/g)].map((match) => match[1]).filter((version) => version.includes(minecraftVersion));
  return versions.reverse().map((version) => ({ version }));
}
async function createVanillaInstance(name: string, minecraftVersion: string, iconData?: string | null, background = 'sky', loader = 'vanilla', loaderVersion?: string): Promise<CreatedInstance> {
  const root = path.join(app.getPath('userData'), 'instances', `${Date.now()}-${name.replace(/[<>:"/\\|?*]/g, '_')}`);
  await fs.mkdir(root, { recursive: true });
  let iconPath: string | undefined;
  const match = iconData?.match(/^data:image\/([a-z0-9+.-]+);base64,(.+)$/i);
  if (match) {
    iconPath = path.join(root, `icon.${match[1]}`);
    await fs.writeFile(iconPath, Buffer.from(match[2], 'base64'));
  }
  const created = { id: path.basename(root), name, path: root, version: minecraftVersion, minecraftVersion, loader, loaderVersion, modpackId: 'vanilla', iconPath, background, installed: true, createdAt: new Date().toISOString() };
  await writeInstances([...(await readInstances()), created]);
  return created;
}
async function installInstance(instanceId: string): Promise<CreatedInstance> {
  const instances = await readInstances();
  const instance = instances.find((item) => item.id === instanceId);
  if (!instance || !instance.packUrl) throw new Error('La instancia no tiene un modpack descargable.');
  if (instance.installed) return instance;
  const zip = new AdmZip(await downloadFile(instance.packUrl));
  const indexEntry = zip.getEntry('modrinth.index.json');
  if (!indexEntry) throw new Error('El archivo descargado no contiene modrinth.index.json.');
  const index = JSON.parse(indexEntry.getData().toString('utf8')) as { files?: { path: string; downloads: string[] }[]; dependencies?: Record<string, string> };
  const entries = zip.getEntries();
  let completed = 0;
  const total = entries.length + (index.files?.length ?? 0);
  for (const entry of entries) {
    if (!entry.entryName.startsWith('overrides/') || entry.isDirectory) continue;
    const destination = path.join(instance.path, safeRelativePath(entry.entryName.slice('overrides/'.length)));
    await fs.mkdir(path.dirname(destination), { recursive: true });
    await fs.writeFile(destination, entry.getData());
    completed += 1;
    BrowserWindow.getAllWindows().forEach((window) => window.webContents.send('instances:progress', instanceId, Math.round((completed / Math.max(total, 1)) * 100), 'Descargando modpack...'));
  }
  for (const file of index.files ?? []) {
    const destination = path.join(instance.path, safeRelativePath(file.path));
    if (!file.downloads[0]) continue;
    await fs.mkdir(path.dirname(destination), { recursive: true });
    await fs.writeFile(destination, await downloadFile(file.downloads[0]));
    completed += 1;
    BrowserWindow.getAllWindows().forEach((window) => window.webContents.send('instances:progress', instanceId, Math.round((completed / Math.max(total, 1)) * 100), 'Descargando archivos...'));
  }
  await fs.writeFile(path.join(instance.path, 'aether-instance.json'), JSON.stringify({ ...instance, installed: true, dependencies: index.dependencies ?? {}, modrinthIndex: index }, null, 2), 'utf8');
  const minecraftVersion = index.dependencies?.minecraft;
  const updated = { ...instance, minecraftVersion, installed: true };
  await writeInstances(instances.map((item) => item.id === instance.id ? updated : item));
  return updated;
}
async function hasInstanceUpdate(instanceId: string) {
  const instance = (await readInstances()).find((item) => item.id === instanceId);
  if (!instance?.installed || !instance.modpackId || instance.modpackId === 'vanilla') return false;
  const versions = await requestJson<{ version_number: string }[]>(`https://api.modrinth.com/v2/project/${encodeURIComponent(instance.modpackId)}/version`, { headers: { 'User-Agent': 'AetherClient/1.0' } });
  return Boolean(versions[0] && versions[0].version_number !== instance.version);
}
async function updateInstance(instanceId: string): Promise<CreatedInstance> {
  const instances = await readInstances();
  const instance = instances.find((item) => item.id === instanceId);
  if (!instance?.modpackId || instance.modpackId === 'vanilla') return instance as CreatedInstance;
  const versions = await requestJson<{ version_number: string; files: { url: string; filename: string; primary?: boolean }[] }[]>(`https://api.modrinth.com/v2/project/${encodeURIComponent(instance.modpackId)}/version`, { headers: { 'User-Agent': 'AetherClient/1.0' } });
  const latest = versions[0];
  const packFile = latest?.files.find((file) => file.filename.toLowerCase().endsWith('.mrpack')) ?? latest?.files.find((file) => file.primary) ?? latest?.files[0];
  if (!latest || !packFile) throw new Error('No se encontró una actualización descargable.');
  const pending = { ...instance, version: latest.version_number, packUrl: packFile.url, installed: false };
  await writeInstances(instances.map((item) => item.id === instanceId ? pending : item));
  return installInstance(instanceId);
}
async function launchInstance(instanceId: string) {
  const instance = (await readInstances()).find((item) => item.id === instanceId);
  if (!instance || !instance.installed) throw new Error('La instancia todavía no está instalada.');
  /*
  const profile = await requestJson<{ id: string; name: string; skins?: { url: string; state: string }[] }>('https://api.minecraftservices.com/minecraft/profile', { headers: { Authorization: `Bearer ${minecraft.access_token}` } });
  */
  const store = await readAccounts();
  const profile = store.accounts.find((account) => account.id === store.activeId);
  if (!profile?.accessToken) throw new Error('Inicia sesión con Microsoft antes de jugar.');
  if (!instance.minecraftVersion) throw new Error('La instancia no tiene una versión exacta de Minecraft. Vuelve a instalarla.');
  const launcher = new MinecraftClient();
  launcher.on('progress', (progress: { task?: number; total?: number }) => {
    const percent = progress.total ? Math.round(((progress.task ?? 0) / progress.total) * 100) : 0;
    BrowserWindow.getAllWindows().forEach((window) => window.webContents.send('instances:progress', instanceId, percent, 'Preparando Minecraft...'));
  });
  launcher.on('progress', (progress: { task?: number; total?: number; type?: string }) => {
    const percent = progress.total ? Math.round(((progress.task ?? 0) / progress.total) * 100) : 0;
    BrowserWindow.getAllWindows().forEach((window) => window.webContents.send('instances:progress', instanceId, percent, 'Preparando Minecraft...'));
  });
  launcher.on('debug', (message: string) => BrowserWindow.getAllWindows().forEach((window) => window.webContents.send('instances:progress', instanceId, 0, message)));
  const authorization = { access_token: profile.accessToken, client_token: profile.clientToken ?? (profile.clientToken = randomUUID()), uuid: profile.id, name: profile.name, user_properties: '{}', meta: { type: 'msa', demo: false } };
  await writeAccounts(store);
  const child = await launcher.launch({ authorization, root: instance.path, version: { number: instance.minecraftVersion, type: 'release' }, memory: { max: '4G', min: '2G' }, overrides: { gameDirectory: instance.path, cwd: instance.path, detached: true } } as never);
  child?.on('error', (error: Error) => console.error('Minecraft terminó con error:', error));
}

async function fileExists(filePath: string) {
  try {
    await access(filePath);
    return true;
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') return false;
    throw error;
  }
}
async function launchInstanceDirect(instanceId: string) {
  if (runningInstances.has(instanceId) || launchingInstances.has(instanceId)) return;
  launchingInstances.add(instanceId);
  const startedAt = Date.now();
  BrowserWindow.getAllWindows().forEach((window) => window.webContents.send('instances:status', instanceId, true, 0));
  try {
  const instance = (await readInstances()).find((item) => item.id === instanceId);
  if (!instance || !instance.installed) throw new Error('La instancia todavía no está instalada.');
  const store = await readAccounts();
  const account = store.accounts.find((item) => item.id === store.activeId);
  if (!account?.accessToken) throw new Error('La cuenta activa fue guardada sin credenciales de juego. Instala la actualización, cierra sesión e inicia sesión nuevamente; esto no indica que hayas perdido Minecraft Premium.');
  if (!instance.minecraftVersion) throw new Error('La instancia no tiene una versión exacta de Minecraft. Vuelve a instalarla.');
  const launcher = new MinecraftClient();
  launcher.on('progress', (progress: { task?: number; total?: number }) => {
    const percent = progress.total ? Math.round(((progress.task ?? 0) / progress.total) * 100) : 0;
    BrowserWindow.getAllWindows().forEach((window) => window.webContents.send('instances:progress', instanceId, percent, 'Preparando Minecraft...'));
  });
  const authorization = { access_token: account.accessToken, client_token: account.clientToken ?? randomUUID(), uuid: account.id, name: account.name, user_properties: '{}', meta: { type: 'msa', demo: false } };
  await writeAccounts({ ...store, accounts: store.accounts.map((item) => item.id === account.id ? { ...item, clientToken: authorization.client_token } : item) });
  const child = await launcher.launch({ authorization, root: instance.path, version: { number: instance.minecraftVersion, type: 'release' }, memory: { max: '4G', min: '2G' }, overrides: { gameDirectory: instance.path, cwd: instance.path, detached: true, maxSockets: 2 } } as never) as ChildProcess | null;
  if (cancelledLaunches.delete(instanceId)) {
    child?.kill();
    return;
  }
  if (!child) throw new Error('No se pudo iniciar el proceso de Minecraft.');
  runningInstances.set(instanceId, { child, startedAt });
  BrowserWindow.getAllWindows().forEach((window) => window.webContents.send('instances:status', instanceId, true, startedAt));
  const clearRunning = () => {
    if (runningInstances.get(instanceId)?.child !== child) return;
    runningInstances.delete(instanceId);
    BrowserWindow.getAllWindows().forEach((window) => window.webContents.send('instances:status', instanceId, false, 0));
  };
  child.once('error', (error) => { console.error('Minecraft terminó con error:', error); clearRunning(); });
  child.once('exit', clearRunning);
  } catch (error) {
    BrowserWindow.getAllWindows().forEach((window) => window.webContents.send('instances:status', instanceId, false, 0));
    throw error;
  } finally {
    launchingInstances.delete(instanceId);
  }
}
function stopInstance(instanceId: string) {
  if (launchingInstances.has(instanceId)) {
    cancelledLaunches.add(instanceId);
    launchingInstances.delete(instanceId);
    BrowserWindow.getAllWindows().forEach((window) => window.webContents.send('instances:status', instanceId, false, 0));
    return true;
  }
  const running = runningInstances.get(instanceId);
  if (running?.child) {
    running.child.kill();
    return true;
  }
  return false;
}
async function listInstancesForRenderer(): Promise<(CreatedInstance & { iconUrl?: string })[]> {
  return Promise.all((await readInstances()).map(async (instance) => ({ ...instance, installed: instance.installed ?? !instance.packUrl, iconUrl: instance.iconPath ? pathToFileURL(instance.iconPath).toString() : undefined })));
}
async function openInstanceFolder(instanceId: string) {
  const instance = (await readInstances()).find((item) => item.id === instanceId);
  if (!instance) throw new Error('La instancia no existe.');
  const instancesRoot = path.resolve(path.join(app.getPath('userData'), 'instances'));
  const resolved = path.resolve(instance.path);
  if (resolved !== instancesRoot && !resolved.startsWith(`${instancesRoot}${path.sep}`)) throw new Error('Ruta de instancia no válida.');
  const error = await shell.openPath(resolved);
  if (error) throw new Error(error);
}
async function deleteInstance(instanceId: string) {
  const instances = await readInstances();
  const instance = instances.find((item) => item.id === instanceId);
  if (!instance) throw new Error('La instancia no existe.');
  const instancesRoot = path.resolve(path.join(app.getPath('userData'), 'instances'));
  const resolved = path.resolve(instance.path);
  if (!resolved.startsWith(`${instancesRoot}${path.sep}`)) throw new Error('Ruta de instancia no válida.');
  await fs.rm(resolved, { recursive: true, force: false });
  await writeInstances(instances.filter((item) => item.id !== instanceId));
}

type DeviceLogin = { deviceCode: string; userCode: string; verificationUri: string; expiresIn: number; interval: number };

async function requestJson<T>(url: string, options: RequestInit): Promise<T> {
  const response = await fetch(url, options);
  const body = await response.text();
  if (!response.ok) throw new Error(`${response.status}: ${body}`);
  return JSON.parse(body) as T;
}
async function requestText(url: string, options: RequestInit): Promise<string> {
  const response = await fetch(url, options);
  const body = await response.text();
  if (!response.ok) throw new Error(`${response.status}: ${body}`);
  return body;
}

async function startMicrosoftLogin(): Promise<DeviceLogin> {
  const body = new URLSearchParams({
    client_id: microsoftClientId,
    scope: 'XboxLive.signin offline_access',
  });
  const result = await requestJson<{ device_code: string; user_code: string; verification_uri: string; expires_in: number; interval: number }>('https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body,
  });
  await shell.openExternal(result.verification_uri);
  return { deviceCode: result.device_code, userCode: result.user_code, verificationUri: result.verification_uri, expiresIn: result.expires_in, interval: result.interval };
}

async function finishMicrosoftLogin(deviceCode: string, interval: number) {
  const body = new URLSearchParams({ client_id: microsoftClientId, grant_type: 'urn:ietf:params:oauth:grant-type:device_code', device_code: deviceCode });
  const deadline = Date.now() + 15 * 60 * 1000;
  let token: { access_token: string } | undefined;
  while (Date.now() < deadline) {
    const response = await fetch('https://login.microsoftonline.com/consumers/oauth2/v2.0/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body });
    const data = await response.json() as { access_token?: string; error?: string };
    if (data.access_token) { token = { access_token: data.access_token }; break; }
    if (data.error !== 'authorization_pending' && data.error !== 'slow_down') throw new Error(data.error ?? 'No se pudo iniciar sesión con Microsoft.');
    await new Promise((resolve) => setTimeout(resolve, (data.error === 'slow_down' ? interval + 5 : interval) * 1000));
  }
  if (!token) throw new Error('El inicio de sesión expiró. Inténtalo nuevamente.');

  const xbox = await requestJson<{ Token: string; DisplayClaims: { xui: [{ uhs: string }] } }>('https://user.auth.xboxlive.com/user/authenticate', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ Properties: { AuthMethod: 'RPS', SiteName: 'user.auth.xboxlive.com', RpsTicket: `d=${token.access_token}` }, RelyingParty: 'http://auth.xboxlive.com', TokenType: 'JWT' }),
  });
  const xsts = await requestJson<{ Token: string; DisplayClaims: { xui: [{ uhs: string }] } }>('https://xsts.auth.xboxlive.com/xsts/authorize', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ Properties: { SandboxId: 'RETAIL', UserTokens: [xbox.Token] }, RelyingParty: 'rp://api.minecraftservices.com/', TokenType: 'JWT' }),
  });
  const minecraft = await requestJson<{ access_token: string }>('https://api.minecraftservices.com/authentication/login_with_xbox', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identityToken: `XBL3.0 x=${xsts.DisplayClaims.xui[0].uhs};${xsts.Token}` }),
  });
  const profile = await requestJson<{ id: string; name: string; skins?: { url: string; state: string }[] }>('https://api.minecraftservices.com/minecraft/profile', { headers: { Authorization: `Bearer ${minecraft.access_token}` } });
  const store = await readAccounts();
  const savedProfile: MinecraftProfile = { id: profile.id, name: profile.name, accessToken: minecraft.access_token, clientToken: randomUUID(), skinUrl: profile.skins?.find((skin) => skin.state === 'ACTIVE')?.url ?? profile.skins?.[0]?.url };
  const accounts = [...store.accounts.filter((account) => account.id !== savedProfile.id), savedProfile];
  await writeAccounts({ accounts, activeId: savedProfile.id });
  return savedProfile;
}

function createWindow() {
  const window = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 980,
    minHeight: 680,
    maximizable: false,
    fullscreenable: false,
    frame: false,
    backgroundColor: '#080d15',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  window.setMenuBarVisibility(false);

  if (isDev) {
    void window.loadURL('http://localhost:5173').catch((error: unknown) => {
      console.error('No se pudo cargar el renderer de desarrollo:', error);
    });
  } else {
    const rendererPath = path.join(app.getAppPath(), 'dist', 'index.html');
    void window.loadFile(rendererPath).catch((error: unknown) => {
      console.error(`No se pudo cargar el renderer desde ${rendererPath}:`, error);
    });
  }

  window.webContents.on('did-fail-load', (_event, errorCode, errorDescription, validatedURL) => {
    console.error(`Falló la carga del renderer (${errorCode}) en ${validatedURL}: ${errorDescription}`);
  });

  window.webContents.on('did-finish-load', () => {
    console.log('Renderer cargado correctamente:', window.webContents.getURL());
  });

  window.webContents.on('console-message', (_event, level, message, line, sourceId) => {
    console.log(`Renderer console [${level}] ${sourceId}:${line} ${message}`);
  });

  window.webContents.on('render-process-gone', (_event, details) => {
    console.error('El proceso del renderer terminó:', details.reason, details.exitCode);
  });
  return window;
}

function configureAutoUpdates(window: BrowserWindow) {
  if (isDev) {
    window.webContents.once('did-finish-load', () => window.webContents.send('launcher:update-status', 'development'));
    return;
  }
  const updateUrl = process.env.AETHER_UPDATE_URL;
  if (updateUrl) autoUpdater.setFeedURL({ provider: 'generic', url: updateUrl });
  else autoUpdater.setFeedURL({ provider: 'github', owner: 'yoellb', repo: 'Aether-Launcher', private: false });
  autoUpdater.autoDownload = true;
  autoUpdater.autoInstallOnAppQuit = true;
  autoUpdater.setFeedURL({ provider: 'generic', url: updateUrl });
  autoUpdater.on('checking-for-update', () => window.webContents.send('launcher:update-status', 'checking'));
  autoUpdater.on('update-available', (info) => window.webContents.send('launcher:update-status', 'available', app.getVersion(), info.version));
  autoUpdater.on('download-progress', (progress) => window.webContents.send('launcher:update-progress', progress.percent));
  autoUpdater.on('update-downloaded', () => {
    window.webContents.send('launcher:update-status', 'downloaded');
    autoUpdater.quitAndInstall(false, true);
  });
  autoUpdater.on('error', (error) => {
    console.error('No se pudo comprobar la actualización:', error);
    window.webContents.send('launcher:update-status', 'error');
  });
  window.webContents.once('did-finish-load', () => {
    window.webContents.send('launcher:update-status', 'checking', app.getVersion());
    void autoUpdater.checkForUpdates();
  });
  ipcMain.handle('launcher:check-updates', async () => {
    window.webContents.send('launcher:update-status', 'checking', app.getVersion());
    const result = await autoUpdater.checkForUpdates();
    return result?.updateInfo ? { currentVersion: app.getVersion(), availableVersion: result.updateInfo.version } : null;
  });
}

app.whenReady().then(() => {
  ipcMain.on('window:minimize', (event) => {
    BrowserWindow.fromWebContents(event.sender)?.minimize();
  });

  ipcMain.on('window:close', (event) => {
    BrowserWindow.fromWebContents(event.sender)?.close();
  });
  ipcMain.on('window:maximize', (event) => {
    const window = BrowserWindow.fromWebContents(event.sender);
    if (!window?.isMaximizable()) return;
    if (window.isMaximized()) window.unmaximize();
    else window.maximize();
  });
  ipcMain.handle('discord:open', () => shell.openExternal('https://discord.gg/HECh6rSBYw'));
  ipcMain.handle('microsoft:open', (_event, url: string) => {
    if (!url.startsWith('https://microsoft.com') && !url.startsWith('https://login.microsoftonline.com')) {
      throw new Error('URL de Microsoft no válida.');
    }
    return shell.openExternal(url);
  });
  ipcMain.handle('external:open', (_event, url: string) => {
    const parsed = new URL(url);
    if (parsed.protocol !== 'https:') throw new Error('Solo se permiten enlaces HTTPS.');
    return shell.openExternal(parsed.toString());
  });
  ipcMain.handle('microsoft:start', () => startMicrosoftLogin());
  ipcMain.handle('microsoft:finish', (_event, deviceCode: string, interval: number) => finishMicrosoftLogin(deviceCode, interval));
  ipcMain.handle('profile:load', async () => {
    const store = await readAccounts();
    return store.accounts.find((account) => account.id === store.activeId) ?? null;
  });
  ipcMain.handle('profile:accounts', async () => (await readAccounts()).accounts);
  ipcMain.handle('profile:activate', async (_event, id: string) => {
    const store = await readAccounts();
    const profile = store.accounts.find((account) => account.id === id);
    if (!profile) throw new Error('La cuenta guardada no existe.');
    await writeAccounts({ ...store, activeId: id });
    return profile;
  });
  ipcMain.handle('profile:clear', async () => {
    const store = await readAccounts();
    await writeAccounts({ ...store, activeId: null });
  });
  ipcMain.handle('settings:load', () => readSettings());
  ipcMain.handle('settings:save', async (_event, settings: LauncherSettings) => writeSettings(settings));
  ipcMain.handle('modpacks:search', (_event, query: string, offset: number) => searchCommunityModpacks(query, offset));
  ipcMain.handle('modpacks:import', () => importMrpack());
  ipcMain.handle('instances:icon', () => selectCustomIcon());
  ipcMain.handle('instances:create-from-modpack', (_event, modpackId: string, name: string, customIcon?: string | null, modpackIconUrl?: string, background?: string) => createCommunityInstance(modpackId, name, customIcon, modpackIconUrl, background));
  ipcMain.handle('instances:create-vanilla', (_event, name: string, version: string, iconData?: string | null, background?: string, loader?: string, loaderVersion?: string) => createVanillaInstance(name, version, iconData, background, loader, loaderVersion));
  ipcMain.handle('minecraft:versions', () => getMinecraftVersions());
  ipcMain.handle('minecraft:loader-versions', (_event, loader: string, version: string) => getLoaderVersions(loader, version));
  ipcMain.handle('instances:list', () => listInstancesForRenderer());
  ipcMain.handle('instances:open-folder', (_event, id: string) => openInstanceFolder(id));
  ipcMain.handle('instances:delete', (_event, id: string) => deleteInstance(id));
  ipcMain.handle('instances:install', (_event, id: string) => installInstance(id));
  ipcMain.handle('instances:launch', (_event, id: string) => launchInstanceDirect(id));
  ipcMain.handle('instances:update-check', (_event, id: string) => hasInstanceUpdate(id));
  ipcMain.handle('instances:update', (_event, id: string) => updateInstance(id));
  ipcMain.handle('instances:stop', (_event, id: string) => stopInstance(id));
  ipcMain.handle('instances:running', (_event, id: string) => {
    const running = runningInstances.get(id);
    return running ? { running: true, startedAt: running.startedAt } : { running: launchingInstances.has(id), startedAt: launchingInstances.has(id) ? Date.now() : 0 };
  });

  const window = createWindow();
  configureAutoUpdates(window);
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
