create extension if not exists "pgcrypto";

create type public.member_role as enum ('creator', 'instance_admin', 'player');
create type public.instance_visibility as enum ('public', 'private');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  minecraft_uuid text unique,
  minecraft_name text,
  role public.member_role not null default 'player',
  created_at timestamptz not null default now(),
  last_seen_at timestamptz
);

create table public.instances (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id),
  name text not null check (length(name) between 1 and 80),
  description text not null default '',
  visibility public.instance_visibility not null default 'private',
  minecraft_version text not null,
  loader text not null default 'vanilla',
  loader_version text,
  manifest jsonb not null default '{}'::jsonb,
  current_version integer not null default 1,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.instance_members (
  instance_id uuid not null references public.instances(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role public.member_role not null default 'instance_admin',
  created_at timestamptz not null default now(),
  primary key (instance_id, user_id)
);

create table public.instance_versions (
  id uuid primary key default gen_random_uuid(),
  instance_id uuid not null references public.instances(id) on delete cascade,
  version integer not null,
  manifest jsonb not null,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  unique (instance_id, version)
);

create table public.audit_log (
  id bigint generated always as identity primary key,
  actor_id uuid not null references public.profiles(id),
  action text not null,
  instance_id uuid references public.instances(id) on delete set null,
  previous_version integer,
  new_version integer,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$ begin
  insert into public.profiles (id) values (new.id) on conflict (id) do nothing;
  return new;
end; $$;
create trigger on_auth_user_created after insert on auth.users
for each row execute function public.handle_new_user();

-- Ejecutar una sola vez, después de iniciar sesión con IsTwenty y sincronizar su UUID:
-- update public.profiles set role = 'creator'
-- where minecraft_uuid = '9419677e7ae44636a573c5e804fd154b'
--   and minecraft_name = 'IsTwenty';

create or replace function public.is_creator()
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.profiles where id = auth.uid() and role = 'creator') $$;

create or replace function public.can_manage_instance(target_id uuid)
returns boolean language sql stable security definer set search_path = public
as $$ select public.is_creator() or exists(
  select 1 from public.instance_members
  where instance_id = target_id and user_id = auth.uid() and role = 'instance_admin'
) $$;

alter table public.profiles enable row level security;
alter table public.instances enable row level security;
alter table public.instance_members enable row level security;
alter table public.instance_versions enable row level security;
alter table public.audit_log enable row level security;

create policy "profiles own row" on public.profiles for select using (id = auth.uid() or public.is_creator());
create policy "profiles self update" on public.profiles for update using (id = auth.uid());
create policy "public or authorized instances" on public.instances for select using (
  visibility = 'public' or owner_id = auth.uid() or public.can_manage_instance(id)
);
create policy "creator creates instances" on public.instances for insert with check (public.is_creator() and owner_id = auth.uid());
create policy "creator or assigned admin updates instances" on public.instances for update using (public.can_manage_instance(id)) with check (public.can_manage_instance(id));
create policy "creator deletes instances" on public.instances for delete using (public.is_creator());
create policy "authorized members visible" on public.instance_members for select using (user_id = auth.uid() or public.is_creator() or public.can_manage_instance(instance_id));
create policy "creator manages members" on public.instance_members for all using (public.is_creator()) with check (public.is_creator());
create policy "versions visible to authorized users" on public.instance_versions for select using (exists(select 1 from public.instances where id = instance_id and (visibility = 'public' or owner_id = auth.uid() or public.can_manage_instance(id))));
create policy "admins publish versions" on public.instance_versions for insert with check (public.can_manage_instance(instance_id) and created_by = auth.uid());
create policy "audit visible to creator or instance admins" on public.audit_log for select using (actor_id = auth.uid() or public.is_creator() or (instance_id is not null and public.can_manage_instance(instance_id)));

create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$ begin new.updated_at = now(); return new; end; $$;
create trigger instances_updated_at before update on public.instances for each row execute function public.touch_updated_at();

create or replace function public.audit_instance_change()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  if auth.uid() is not null then
    insert into public.audit_log(actor_id, action, instance_id, details)
    values (auth.uid(), tg_op, new.id, jsonb_build_object('name', new.name, 'visibility', new.visibility));
  end if;
  return new;
end;
$$;
drop trigger if exists instances_audit on public.instances;
create trigger instances_audit after update on public.instances for each row execute function public.audit_instance_change();

-- Migración segura para instalaciones que ya ejecutaron la versión anterior:
drop policy if exists "audit visible to creator or instance admins" on public.audit_log;
create policy "audit visible to creator or instance admins" on public.audit_log for select using (
  public.is_creator() or actor_id = auth.uid() or (instance_id is not null and public.can_manage_instance(instance_id))
);
