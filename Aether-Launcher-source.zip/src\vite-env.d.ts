/// <reference types="vite/client" />

interface Window {
  aether?: {
    minimize: () => void;
    close: () => void;
    openDiscord: () => Promise<void>;
    openMicrosoft: (url: string) => Promise<void>;
    openExternal: (url: string) => Promise<void>;
    startMicrosoftLogin: () => Promise<{ deviceCode: string; userCode: string; verificationUri: string; expiresIn: number; interval: number }>;
    finishMicrosoftLogin: (deviceCode: string, interval: number) => Promise<{ id: string; name: string }>;
    loadProfile: () => Promise<{ id: string; name: string; skinUrl?: string } | null>;
    clearProfile: () => Promise<void>;
    maximize: () => void;
    loadAccounts: () => Promise<{ id: string; name: string; skinUrl?: string }[]>;
    activateProfile: (id: string) => Promise<{ id: string; name: string; skinUrl?: string }>;
    loadSettings: () => Promise<Record<string, string | boolean>>;
    saveSettings: (settings: Record<string, string | boolean>) => Promise<void>;
    searchModpacks: (query: string, offset?: number) => Promise<{ items: { id: string; title: string; description: string; version: string; iconUrl?: string; downloads: number; source: 'Modrinth' }[]; hasMore: boolean }>;
    importMrpack: () => Promise<{ name: string; path: string } | null>;
    selectCustomIcon: () => Promise<string | null>;
    createInstanceFromModpack: (modpackId: string, name: string, customIcon?: string | null, iconUrl?: string, background?: string) => Promise<{ id: string; name: string; path: string; version: string; minecraftVersion?: string; modpackId: string; packUrl?: string; iconPath?: string; iconUrl?: string; background?: string; installed?: boolean; createdAt: string }>;
    createVanillaInstance: (name: string, version: string, iconData?: string | null, background?: string, loader?: string, loaderVersion?: string) => Promise<unknown>;
    getMinecraftVersions: () => Promise<{ id: string; type: string }[]>;
    getLoaderVersions: (loader: string, version: string) => Promise<{ version: string }[]>;
    listInstances: () => Promise<{ id: string; name: string; path: string; version: string; minecraftVersion?: string; modpackId: string; iconPath?: string; iconUrl?: string; createdAt: string }[]>;
    openInstanceFolder: (id: string) => Promise<void>;
    deleteInstance: (id: string) => Promise<void>;
    installInstance: (id: string) => Promise<{ id: string; name: string; path: string; version: string; minecraftVersion?: string; modpackId: string; installed?: boolean }>;
    launchInstance: (id: string) => Promise<void>;
    stopInstance: (id: string) => Promise<boolean>;
    isInstanceRunning: (id: string) => Promise<{ running: boolean; startedAt: number }>;
    onInstanceStatus: (callback: (id: string, running: boolean, startedAt: number) => void) => () => void;
    onInstanceProgress: (callback: (id: string, percent: number, message: string) => void) => () => void;
    hasInstanceUpdate: (id: string) => Promise<boolean>;
    updateInstance: (id: string) => Promise<unknown>;
    checkLauncherUpdates: () => Promise<{ currentVersion: string; availableVersion: string } | null>;
    onLauncherUpdateStatus: (callback: (status: string, currentVersion?: string, availableVersion?: string) => void) => () => void;
    onLauncherUpdateProgress: (callback: (percent: number) => void) => () => void;
  };
}
